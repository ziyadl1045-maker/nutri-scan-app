import { z } from 'zod';
import { users } from './models/auth';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  profile: {
    update: {
      method: 'PATCH' as const,
      path: '/api/profile',
      input: z.object({
        age: z.number().min(0).max(120).optional(),
        gender: z.string().optional(),
        firstName: z.string().optional(),
        lastName: z.string().optional(),
      }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.internal, // Unauthorized
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/profile',
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.internal,
      },
    },
  },
  products: {
    lookup: {
      method: 'GET' as const,
      path: '/api/products/:barcode',
      responses: {
        200: z.object({
          name: z.string(),
          brand: z.string().optional(),
          nutriments: z.record(z.any()).optional(),
        }),
        404: errorSchemas.notFound,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

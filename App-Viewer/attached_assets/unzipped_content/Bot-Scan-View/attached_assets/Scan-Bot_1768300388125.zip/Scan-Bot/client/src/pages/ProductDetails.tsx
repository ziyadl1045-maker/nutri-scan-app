import { useRoute, Link, useLocation } from "wouter";
import { useProduct } from "@/hooks/use-products";
import { HealthGauge } from "@/components/HealthGauge";
import { BottomNav } from "@/components/BottomNav";
import { ArrowLeft, Share2, Info, Search, Sparkles, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { useState } from "react";
import { api } from "@shared/routes";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function ProductDetails() {
  const [match, params] = useRoute("/product/:barcode");
  const [, setLocation] = useLocation();
  const barcode = match ? params.barcode : null;
  const { data: product, isLoading, error } = useProduct(barcode);
  const [searchName, setSearchName] = useState("");

  const aiLookupMutation = useMutation({
    mutationFn: async (name: string) => {
      const res = await apiRequest("POST", api.products.aiLookup.path, { name });
      return res.json();
    },
  });
  
  // Real health score calculation (simplified Nutri-Score logic)
  const calculateScore = (p: any) => {
    if (!p || !p.nutriments) return 0;
    
    let points = 0;
    const n = p.nutriments as Record<string, any>;
    
    // Negative points (bad)
    const energy = p.calories || 0;
    if (energy > 800) points += 10;
    else if (energy > 160) points += Math.floor(energy / 80);
    
    const sugars = parseFloat(n.sugars) || 0;
    if (sugars > 45) points += 10;
    else if (sugars > 4.5) points += Math.floor(sugars / 4.5);
    
    const satFat = parseFloat(n['saturated-fat']) || 0;
    if (satFat > 10) points += 10;
    else if (satFat > 1) points += Math.floor(satFat / 1);
    
    const salt = parseFloat(n.salt) || 0;
    if (salt > 0.9) points += 10;
    else if (salt > 0.1) points += Math.floor(salt / 0.1);
    
    // Positive points (good)
    const proteins = parseFloat(n.proteins) || 0;
    const fiber = parseFloat(n.fiber) || 0;
    
    const goodPoints = Math.min(5, Math.floor(proteins / 1.6)) + Math.min(5, Math.floor(fiber / 0.9));
    
    const finalScore = points - goodPoints;
    
    // Map to 0-100 scale (inverted because finalScore is higher for bad products)
    // Nutri-Score ranges from -15 (best) to 40 (worst)
    // Let's normalize: 0 is worst, 100 is best
    return Math.max(0, Math.min(100, 100 - (finalScore + 15) * 2));
  };

  const currentProduct = aiLookupMutation.data || product;
  const score = calculateScore(currentProduct);

  const getRecommendation = (s: number) => {
    if (s >= 80) return "Excellent product! You can enjoy this daily.";
    if (s >= 60) return "Good choice for a balanced diet.";
    if (s >= 40) return "Moderate. Try to consume this occasionally.";
    if (s >= 20) return "Poor nutritional quality. Limit your consumption.";
    return "Very poor. Better to find a healthier alternative.";
  };

  if (isLoading || aiLookupMutation.isPending) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-12 h-12 text-primary animate-spin" />
          {aiLookupMutation.isPending && <p className="text-sm font-medium text-muted-foreground animate-pulse">AI is estimating nutrition...</p>}
        </div>
      </div>
    );
  }

  if ((error || !product) && !aiLookupMutation.data) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center p-8 text-center">
        <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mb-6">
          <Info className="w-8 h-8 text-red-500" />
        </div>
        <h2 className="text-2xl font-bold mb-2">Product Not Found</h2>
        <p className="text-muted-foreground mb-8">
          We couldn't find a product with barcode <span className="font-mono font-bold text-foreground">{barcode}</span>. 
          Would you like to search by name instead?
        </p>
        
        <div className="w-full max-w-sm space-y-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input 
              type="text"
              placeholder="Enter product name (e.g. Whole Milk)"
              className="w-full h-14 pl-12 pr-4 rounded-2xl bg-gray-50 border-none focus:ring-2 focus:ring-primary/20 transition-all text-lg"
              value={searchName}
              onChange={(e) => setSearchName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && searchName && aiLookupMutation.mutate(searchName)}
            />
          </div>
          <button 
            disabled={!searchName}
            onClick={() => aiLookupMutation.mutate(searchName)}
            className="w-full h-14 bg-slate-900 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-slate-800 disabled:opacity-50 transition-all active:scale-95"
          >
            <Sparkles className="w-5 h-5" />
            Estimate with AI
          </button>
          
          <div className="pt-4">
            <Link href="/scan" className="text-sm font-semibold text-primary hover:underline">
              Scan Another Product
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const displayProduct = currentProduct;

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <div className="bg-white px-6 pt-6 pb-6 sticky top-0 z-10 shadow-sm flex items-center justify-between">
        <Link href="/scan">
          <div className="p-2 -ml-2 hover:bg-gray-100 rounded-full cursor-pointer transition">
            <ArrowLeft className="w-6 h-6 text-slate-800" />
          </div>
        </Link>
        <h1 className="font-bold text-slate-800">Product Analysis</h1>
        <Share2 className="w-6 h-6 text-slate-800" />
      </div>

      <div className="px-6 py-8 space-y-8">
        {/* Product Identity */}
        <div className="text-center">
          <div className="w-24 h-24 bg-white rounded-2xl mx-auto mb-4 shadow-md border border-gray-100 flex items-center justify-center">
            {/* Placeholder for product image if not available */}
             <span className="text-2xl font-bold text-gray-300">IMG</span>
          </div>
          <h2 className="text-2xl font-bold text-slate-900 font-display mb-1">{displayProduct.name}</h2>
          <p className="text-muted-foreground">{displayProduct.brand || "Unknown Brand"}</p>
          {displayProduct.isAI && (
            <div className="mt-2 inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-amber-50 text-amber-700 text-[10px] font-bold uppercase tracking-wider border border-amber-100">
              <Info className="w-3 h-3" />
              AI Estimate
            </div>
          )}
        </div>

        {/* Gauge */}
        <div className="space-y-2">
          <HealthGauge score={score} />
          <p className="text-center text-sm font-medium text-slate-600 px-4">
            {getRecommendation(score)}
          </p>
        </div>

        {/* Nutrients Grid */}
        <div>
          <h3 className="text-lg font-bold text-slate-900 mb-4">Nutritional Breakdown</h3>
          <div className="grid grid-cols-2 gap-4">
            <NutrientCard 
              label="Sugars" 
              value={`${Math.round(displayProduct.nutriments?.sugars || 0)}g`} 
              status={parseFloat(displayProduct.nutriments?.sugars) > 10 ? "Too High" : "Reasonable"}
              color={parseFloat(displayProduct.nutriments?.sugars) > 10 ? "red" : "green"}
            />
             <NutrientCard 
              label="Fat" 
              value={`${Math.round(displayProduct.nutriments?.fat || 0)}g`} 
              status={parseFloat(displayProduct.nutriments?.fat) > 15 ? "High" : "Moderate"}
              color={parseFloat(displayProduct.nutriments?.fat) > 15 ? "red" : "orange"}
            />
            <NutrientCard 
              label="Protein" 
              value={`${Math.round(displayProduct.nutriments?.proteins || 0)}g`} 
              status="Healthy"
              color="green"
            />
            <NutrientCard 
              label="Salt" 
              value={`${(displayProduct.nutriments?.salt || 0).toFixed(2)}g`} 
              status={parseFloat(displayProduct.nutriments?.salt) > 1.5 ? "High" : "Low"}
              color={parseFloat(displayProduct.nutriments?.salt) > 1.5 ? "red" : "green"}
            />
            <NutrientCard 
              label="Calories" 
              value={`${Math.round(displayProduct.calories || 0)} kcal`} 
              status={displayProduct.calories > 400 ? "High" : "Normal"}
              color={displayProduct.calories > 400 ? "red" : "green"}
            />
          </div>
        </div>

        {/* Additives Section */}
        {displayProduct.additives && displayProduct.additives.length > 0 && (
          <div>
            <h3 className="text-lg font-bold text-slate-900 mb-4">Chemical Additives</h3>
            <div className="flex flex-wrap gap-2">
              {displayProduct.additives.map((additive: string, idx: number) => (
                <div key={idx} className="px-3 py-1.5 bg-red-50 text-red-700 border border-red-100 rounded-lg text-sm font-medium">
                  {additive}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* AI Analysis CTA */}
        <Link href="/chat">
          <motion.div 
            whileTap={{ scale: 0.98 }}
            className="p-6 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-500/20 cursor-pointer"
          >
            <h3 className="font-bold text-lg mb-1">Have questions?</h3>
            <p className="text-emerald-100 text-sm mb-4">Ask our AI nutritionist about this product.</p>
            <div className="inline-flex px-4 py-2 bg-white/20 backdrop-blur-md rounded-lg text-sm font-medium">
              Start Chat
            </div>
          </motion.div>
        </Link>
      </div>

      <BottomNav />
    </div>
  );
}

function NutrientCard({ label, value, status, color }: { label: string, value: string, status: string, color: string }) {
  const colorClass = {
    red: "text-red-600 bg-red-50 border-red-100",
    orange: "text-orange-600 bg-orange-50 border-orange-100",
    green: "text-emerald-600 bg-emerald-50 border-emerald-100"
  }[color] || "text-gray-600 bg-gray-50 border-gray-100";

  return (
    <div className={`p-4 rounded-xl border ${colorClass} bg-opacity-50`}>
      <p className="text-sm font-medium opacity-80 mb-1">{label}</p>
      <div className="flex items-end justify-between">
        <span className="text-xl font-bold">{value}</span>
        <span className="text-xs font-bold uppercase tracking-wider opacity-70">{status}</span>
      </div>
    </div>
  );
}
